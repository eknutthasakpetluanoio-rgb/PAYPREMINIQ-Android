# PAYPREMINIQ Android — Build Ready

This project is designed for building from GitHub Actions without Android Studio.

The APK opens the live PAYPREMINIQ GitHub Pages site as a native Android WebView app:
https://eknutthasakpetluanoio-rgb.github.io/PAYPREMINIQ/

## Build from a phone

1. Create/open a GitHub repository.
2. Upload the contents of this folder, including `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab.
4. Run **Build PAYPREMINIQ APK** (or push to `main`).
5. Open the completed workflow run.
6. Download the artifact **PAYPREMINIQ-debug-apk**.
7. Extract the ZIP and install `app-debug.apk` on Android.

The APK is a debug build for personal installation/testing. It is not a Play Store release build.
